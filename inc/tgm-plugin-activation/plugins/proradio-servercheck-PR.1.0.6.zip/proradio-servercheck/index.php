<?php  
/* Silence is golden. */