<?php

require_once 'bench-class.php';

benchmark::run();

	
?>